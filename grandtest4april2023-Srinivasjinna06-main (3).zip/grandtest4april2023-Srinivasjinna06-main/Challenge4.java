import java.util.*;

class Task {
  int id;
  String name;
  String description;
  String dueDate;
  String status;

  public Task(int id, String name, String description, String dueDate, String status) {
    this.id = id;
    this.name = name;
    this.description = description;
    this.dueDate = dueDate;
    this.status = status;
  }
}

public class Challenge4 {
  private HashSet<Integer> taskIds = new HashSet<>();
  private List<Task> tasks = new ArrayList<>();
  private Scanner scanner = new Scanner(System.in);

  public void addTask(int id, String name, String description, String dueDate, String status) {
    if (taskIds.contains(id)) {
      System.out.println("Task with ID " + id + " already exists.");
      return;
    }
    taskIds.add(id);
    Task task = new Task(id, name, description, dueDate, status);
    tasks.add(task);
    System.out.println("Task added successfully.");
  }

  public void removeTask(int id) {
    Iterator<Task> iterator = tasks.iterator();
    while (iterator.hasNext()) {
      Task task = iterator.next();
      if (task.id == id) {
        iterator.remove();
        taskIds.remove(id);
        System.out.println("Task removed successfully.");
        return;
      }
    }
    System.out.println("Task not found.");
  }

  public void updateTaskStatus(int id, String newStatus) {
    for (Task task : tasks) {
      if (task.id == id) {
        task.status = newStatus;
        System.out.println("Task status updated successfully.");
        return;
      }
    }
    System.out.println("Task not found.");
  }

  public void displayAllTasks() {
    for (Task task : tasks) {
      System.out.println("Task ID: " + task.id);
      System.out.println("Name: " + task.name);
      System.out.println("Description: " + task.description);
      System.out.println("Due Date: " + task.dueDate);
      System.out.println("Status: " + task.status);
      System.out.println();
    }
  }

  public void displayTasksByStatus(String targetStatus) {
    for (Task task : tasks) {
      if (task.status.equalsIgnoreCase(targetStatus)) {
        System.out.println("Task ID: " + task.id);
        System.out.println("Name: " + task.name);
        System.out.println("Description: " + task.description);
        System.out.println("Due Date: " + task.dueDate);
        System.out.println("Status: " + task.status);
        System.out.println();
      }
    }
  }

  public static void main(String[] args) {
    Challenge4 taskManager = new Challenge4();
    Scanner scanner = new Scanner(System.in);

    while (true) {
      System.out.println("\nMenu:");
      System.out.println("1. Add Task");
      System.out.println("2. Remove Task");
      System.out.println("3. Update Status of Task");
      System.out.println("4. Display All Tasks");
      System.out.println("5. Display 'in progress' Tasks");
      System.out.println("6. Display 'completed' Tasks");
      System.out.println("7. Display 'overdue' Tasks");
      System.out.println("8. Exit");

      System.out.print("Enter your choice: ");
      int choice = scanner.nextInt();
      scanner.nextLine();

      switch (choice) {
        case 1:
          System.out.print("Enter Task ID: ");
          int taskId = scanner.nextInt();
          scanner.nextLine();
          System.out.print("Enter Name: ");
          String name = scanner.nextLine();
          System.out.print("Enter Description: ");
          String description = scanner.nextLine();
          System.out.print("Enter Due Date: ");
          String dueDate = scanner.nextLine();
          System.out.print("Enter Status: ");
          String status = scanner.nextLine();
          taskManager.addTask(taskId, name, description, dueDate, status);
          break;
        case 2:
          System.out.print("Enter Task ID to remove: ");
          int removeId = scanner.nextInt();
          taskManager.removeTask(removeId);
          break;
        case 3:
          System.out.print("Enter Task ID to update status: ");
          int updateId = scanner.nextInt();
          scanner.nextLine(); // Consume the newline
          System.out.print("Enter new status: ");
          String newStatus = scanner.nextLine();
          taskManager.updateTaskStatus(updateId, newStatus);
          break;
        case 4:
          taskManager.displayAllTasks();
          break;
        case 5:
          taskManager.displayTasksByStatus("in progress");
          break;
        case 6:
          taskManager.displayTasksByStatus("completed");
          break;
        case 7:
          taskManager.displayTasksByStatus("overdue");
          break;
        case 8:
          System.out.println("Exiting program.");
          scanner.close();
          System.exit(0);
        default:
          System.out.println("Invalid choice.");
      }
    }
  }
}
