import java.util.*;

public class Challenge3 {
    private static final int MAX_SIZE = 10;
    private int[] stack = new int[MAX_SIZE];
    private int top = -1;
    private Scanner scanner = new Scanner(System.in);

    public void push(int value) {
        if (top == MAX_SIZE - 1) {
            System.out.println("Stack is full. Cannot push element.");
            return;
        }
        stack[++top] = value;
        System.out.println("Element " + value + " pushed to the stack.");
    }

    public void pop() {
        if (top == -1) {
            System.out.println("Stack is empty. Cannot pop element.");
            return;
        }
        int poppedElement = stack[top--];
        System.out.println("Popped element: " + poppedElement);
    }

    public void peek() {
        if (top == -1) {
            System.out.println("Stack is empty. Cannot peek.");
            return;
        }
        System.out.println("Top element: " + stack[top]);
    }

    public void display() {
        if (top == -1) {
            System.out.println("Stack is empty.");
            return;
        }
        System.out.println("Stack elements:");
        for (int i = top; i >= 0; i--) {
            System.out.println(stack[i]);
        }
    }

    public static void main(String[] args) {
        Challenge3 stackProgram = new Challenge3();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1.push");
            System.out.println("2.pop");
            System.out.println("3.peek");
            System.out.println("4.display");
            System.out.println("5.exit");

            System.out.print("Enter your command: ");
            String input = scanner.nextLine();

            String[] command = input.split(" ");
            int value;

            switch (command[0]) {
                case "push":
                    if (command.length != 2) {
                        System.out.println("Invalid command format. Usage: push");
                        break;
                    }
                    try {
                        value = Integer.parseInt(command[1]);
                        stackProgram.push(value);
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid value. Please provide an integer.");
                    }
                    break;

                case "pop":
                    stackProgram.pop();
                    break;

                case "peek":
                    stackProgram.peek();
                    break;

                case "display":
                    stackProgram.display();
                    break;

                case "exit":
                    System.out.println("Exiting program.");
                    scanner.close();
                    System.exit(0);

                default:
                    System.out.println("Invalid command.");
            }
        }
    }
}