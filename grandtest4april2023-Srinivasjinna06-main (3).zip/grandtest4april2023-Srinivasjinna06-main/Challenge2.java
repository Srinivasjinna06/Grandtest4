import java.util.*;

public class Challenge2 {
  private Map<String, String> dictionary = new HashMap<>();
  private Scanner scanner = new Scanner(System.in);

  public void addWordAndDefinition() {
    System.out.print("Enter the word: ");
    String word = scanner.nextLine();

    if (dictionary.containsKey(word)) {
      System.out.println("Word already exists in the dictionary.");
      return;
    }

    System.out.print("Enter the definition: ");
    String definition = scanner.nextLine();
    dictionary.put(word, definition);
    System.out.println("Word and definition added successfully.");
  }

  public void viewDefinition() {
    System.out.print("Enter the word to view its definition: ");
    String word = scanner.nextLine();

    if (dictionary.containsKey(word)) {
      System.out.println("Definition: " + dictionary.get(word));
    } else {
      System.out.println("Word not found in the dictionary.");
    }
  }

  public void numberOfWords() {
    int count = dictionary.size();
    System.out.println("Number of words in the dictionary: " + count);
  }

  public void searchWords() {
    System.out.print("Enter a search keyword: ");
    String keyword = scanner.nextLine();

    System.out.println("Words matching '" + keyword + "':");
    for (String word : dictionary.keySet()) {
      if (word.contains(keyword)) {
        System.out.println("- " + word);
      }
    }
  }

  public static void main(String[] args) {
    Challenge2 dictionaryProgram = new Challenge2();
    Scanner scanner = new Scanner(System.in);

    while (true) {
      System.out.println("\nMenu:");
      System.out.println("1. Add Word and its definition");
      System.out.println("2. View Definition");
      System.out.println("3. Number of Words");
      System.out.println("4. Search Words");
      System.out.println("5. Exit");

      System.out.print("Enter your choice: ");
      int choice = scanner.nextInt();
      scanner.nextLine();

      switch (choice) {
        case 1:
          dictionaryProgram.addWordAndDefinition();
          break;
        case 2:
          dictionaryProgram.viewDefinition();
          break;
        case 3:
          dictionaryProgram.numberOfWords();
          break;
        case 4:
          dictionaryProgram.searchWords();
          break;
        case 5:
          System.out.println("Exiting program.");
          scanner.close();
          System.exit(0);
        default:
          System.out.println("Invalid choice.");
      }
    }
  }
}