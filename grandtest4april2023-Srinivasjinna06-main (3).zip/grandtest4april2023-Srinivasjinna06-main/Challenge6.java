import java.util.*;

public class Challenge6 {
    public static int findClosestElement(int[] arr, int target) {
        int left = 0;
        int right = arr.length - 1;
        int closest = -1;

        while (left <= right) {
            int mid = left + (right - left) / 2;

            if (arr[mid] == target) {
                return arr[mid];
            }

            if (closest == -1 || Math.abs(arr[mid] - target) < Math.abs(closest - target)) {
                closest = arr[mid];
            }

            if (arr[mid] < target) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }

        return closest;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the size of the sorted array: ");
        int size = scanner.nextInt();
        int[] arr = new int[size];

        System.out.println("Enter the sorted array elements:");
        for (int i = 0; i < size; i++) {
            arr[i] = scanner.nextInt();
        }

        System.out.print("Enter the target value: ");
        int target = scanner.nextInt();

        Arrays.sort(arr); 

        int closestElement = findClosestElement(arr, target);
        if (closestElement == -1) {
            System.out.println("No closest element found.");
        } else {
            System.out.println("Closest element: " + closestElement);
        }

        scanner.close();
    }
}